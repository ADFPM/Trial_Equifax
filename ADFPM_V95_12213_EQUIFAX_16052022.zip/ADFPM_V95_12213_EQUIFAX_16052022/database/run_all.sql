--
-- Creates all adf metrics database objects
--

--main table
start adf_metrics_process_requests.tab
start adf_metrics_requests.tab
start adf_metrics_exceptions.tab
start adf_metrics_request_clobs.tab
start adf_metrics_jmx.tab

--detail tables
start adf_metrics_viewobjects.tab
start adf_metrics_am_pooling.tab
start adf_metrics_am_transactions.tab
start adf_metrics_dc_operations.tab
start adf_metrics_eo_dml.tab
start adf_metrics_plsql_calls.tab
start adf_metrics_vo_queries.tab
start adf_metrics_process_exc.tab
start adf_metrics_dc_iterator.tab
start adf_metrics_webservice_calls.tab
start adf_metrics_java_methods.tab
start adf_metrics_parameters.tab
start adf_metrics_caching_rows.tab
start adf_metrics_exec_to_ignore.tab
start adf_metrics_monitored_users.tab
start adf_metrics_aggr_job_exc.tab
start adf_metrics_hour_aggregated.tab
start adf_metrics_day_aggregated.tab

--view
start adf_metrics_exceptions_vw.vw;
start adf_metrics_requests_vw.vw
start adf_metrics_requests_old_vw.vw
start adf_metrics_requests_err_vw.vw
start adf_metrics_requests_dtl_vw.vw
start adf_metrics_plsql_calls_vw.vw
start adf_metrics_vo_queries_vw.vw
start adf_metrics_am_transactions_vw.vw
start adf_metrics_am_pooling_vw.vw
start adf_metrics_dc_operations_vw.vw
start adf_metrics_eo_dml_vw.vw
start adf_metrics_dc_iterator_vw.vw
start adf_metrics_webs_calls_vw.vw
start adf_metrics_java_methods_vw.vw
start adf_metrics_caching_rows_vw.vw;

--sequence
start adf_metrics_seq.sqs

--packages
start adf_metrics.pks
start adf_metrics.pkb
start adf_metrics_job.pks
start adf_metrics_job.pkb
start adf_metrics_hour_aggr_job.pks
start adf_metrics_hour_aggr_job.pkb
start adf_metrics_day_aggr_job.pks
start adf_metrics_day_aggr_job.pkb

--batchjob
start create_job_dbms_schedule.sql
start create_job_dbms_schedule_cleanup.sql
start create_hour_aggr_job_dbms_schedule.sql
start create_day_aggr_job_dbms_schedule.sql

--parameters
start adf_metrics_parameter_values.sql