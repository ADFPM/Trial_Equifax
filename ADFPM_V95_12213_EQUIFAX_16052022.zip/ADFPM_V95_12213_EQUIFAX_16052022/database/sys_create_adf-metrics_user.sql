prompt
prompt creatie adf_metrics user
prompt


create user adf_metrics identified by adf_metrics;
grant connect, resource, create view, scheduler_admin to adf_metrics;

--
--****************** EXAMPLE --> ADJUST YOUR DATAFILE LOCATION ***********************************
--
CREATE TABLESPACE "ADF_METRICS_DATA" DATAFILE 'C:\oraclexe\app\oracle\oradata\XE\adf_metrics_dat01.dbf' 
SIZE 100M AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
--
alter user adf_metrics default tablespace adf_metrics_data temporary tablespace temp;
grant unlimited tablespace to adf_metrics;
