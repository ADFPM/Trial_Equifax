set serveroutput on size 1000000
declare

begin
   DBMS_SCHEDULER.DROP_JOB('adf_metrics_aggregate_jvm_job',true);
   --DBMS_SCHEDULER.DROP_JOB('TEST_FULL_JOB_DEFINITION');
   
end;
/