create or replace PROCEDURE send_mail_from_database
                                      (p_to        IN VARCHAR2,
                                       p_from      IN VARCHAR2,
                                       p_subject   IN VARCHAR2,
                                       p_message   IN VARCHAR2,
                                       p_smtp_host IN VARCHAR2,
                                       p_smtp_port IN NUMBER
                                       )
AS
  --
  l_mail_conn   utl_smtp.connection;
  l_smtp_host   varchar2(100) := p_smtp_host;
  l_smtp_port   number(2)     := p_smtp_port;
  --
BEGIN
  --
  l_mail_conn := utl_smtp.open_connection(l_smtp_host, l_smtp_port);
  utl_smtp.helo(l_mail_conn, l_smtp_host);
  utl_smtp.mail(l_mail_conn, p_from);
  utl_smtp.rcpt(l_mail_conn, p_to);
  --
  utl_smtp.open_data(l_mail_conn);
  utl_smtp.write_data(l_mail_conn, 'Date: ' || to_char(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') || utl_tcp.crlf);
  utl_smtp.write_data(l_mail_conn, 'To: ' || p_to || utl_tcp.crlf);
  utl_smtp.write_data(l_mail_conn, 'From: ' || p_from || utl_tcp.crlf);
  utl_smtp.write_data(l_mail_conn, 'Subject: ' || p_subject || utl_tcp.crlf);
  utl_smtp.write_data(l_mail_conn, 'Reply-To: ' || p_from || utl_tcp.crlf || utl_tcp.crlf);
  utl_smtp.write_data(l_mail_conn, p_message || utl_tcp.crlf || utl_tcp.crlf);
  utl_smtp.close_data(l_mail_conn);
  --
  utl_smtp.quit(l_mail_conn);
  --
EXCEPTION
  WHEN utl_smtp.transient_error OR utl_smtp.permanent_error THEN
    BEGIN
      utl_smtp.quit(l_mail_conn);
    EXCEPTION
      WHEN utl_smtp.transient_error OR utl_smtp.permanent_error THEN
        NULL;
    END;
    raise_application_error(-20000, SQLERRM);
END;