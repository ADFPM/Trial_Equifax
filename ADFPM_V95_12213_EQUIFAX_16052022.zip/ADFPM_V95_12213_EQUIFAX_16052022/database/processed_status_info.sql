select count(*) from adf_metrics_requests;
select count(*) from adf_metrics_process_exc;
select count(*) from adf_metrics_process_requests where status = 'TODO';
select count(*) from adf_metrics_process_requests where status = 'PROCESSING';