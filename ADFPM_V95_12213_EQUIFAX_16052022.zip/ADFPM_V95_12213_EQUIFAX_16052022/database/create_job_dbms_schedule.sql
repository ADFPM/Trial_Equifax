declare
begin
    dbms_scheduler.create_job (
      job_name        => 'adf_metrics_process_xml_job',
      job_type        => 'PLSQL_BLOCK',
      job_action      => 'BEGIN adf_metrics_job.process_metrics(); END;',
      start_date      => systimestamp,
      repeat_interval => 'freq=secondly;interval=10',
      end_date        => null,
      enabled         => true,
      comments        => 'Job defined to process adf_metrics xml to detail tables');
end;
/