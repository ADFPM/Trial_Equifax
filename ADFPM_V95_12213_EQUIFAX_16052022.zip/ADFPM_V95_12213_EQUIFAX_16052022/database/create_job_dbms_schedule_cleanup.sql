declare
begin
    dbms_scheduler.create_job (
      job_name        => 'adf_metrics_cleanup_job',
      job_type        => 'PLSQL_BLOCK',
      job_action      => 'BEGIN adf_metrics_job.cleanup_old_metrics; END;',
      start_date      => systimestamp,
      repeat_interval => 'freq=daily;byhour=0;byminute=0;bysecond=0;',
      end_date        => null,
      enabled         => true,
      comments        => 'Job defined to cleanup adf_metrics rows');
end;
/