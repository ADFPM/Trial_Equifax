set serveroutput on size 1000000
declare

begin
   DBMS_SCHEDULER.DROP_JOB('adf_metrics_aggr_job_hour',true);   
end;
/