--
--this script empties rows of adf_metrics tables that are 30 days or older
--

--adf_metrics_requests
delete from adf_metrics_requests
where  to_date (TO_CHAR(request_time,'dd/mon/yyyy:hh24'),'dd/mon/yyyy:hh24')< to_date (TO_CHAR(sysdate-30,'dd/mon/yyyy:hh24'),'dd/mon/yyyy:hh24')
;
commit;