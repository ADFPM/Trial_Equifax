set serveroutput on size 1000000
declare

begin
   DBMS_SCHEDULER.DROP_JOB('adf_metrics_cleanup_job',true);   
end;
/