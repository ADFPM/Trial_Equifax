declare
begin
    dbms_scheduler.create_job (
      job_name        => 'adf_metrics_aggregate_jvm_job',
      job_type        => 'PLSQL_BLOCK',
      job_action      => 'BEGIN adf_metrics_job.aggregate_jvm_metrics; END;',
      start_date      => systimestamp,
      repeat_interval => 'freq=minutely;byminute=0,5,10,15,20,25,30,35,40,45,50,55;bysecond=0',
      end_date        => null,
      enabled         => true,
      comments        => 'Job defined to process adf_metrics jvm to minute aggregate');
end;
/