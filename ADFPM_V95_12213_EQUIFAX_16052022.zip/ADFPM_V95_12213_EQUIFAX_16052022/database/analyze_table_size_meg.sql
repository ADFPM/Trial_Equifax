
alter table adf_metrics_process_requests modify lob (all_metrics) (shrink space);
alter table adf_metrics_request_clobs    modify lob (all_metrics) (shrink space);
alter table adf_metrics_exceptions       modify lob (stacktrace)  (shrink space);
alter table adf_metrics_process_exc      modify lob (all_metrics) (shrink space);


select table_name
,      table_size_meg
,      round((table_size_meg/sum(table_size_meg) over ())*100, 1) perc_size
from
(
select
   segment_name           table_name,  
   sum(bytes)/(1024*1024) table_size_meg
from 
   user_extents
group by segment_name
)
order by  table_size_meg desc, table_name
/
