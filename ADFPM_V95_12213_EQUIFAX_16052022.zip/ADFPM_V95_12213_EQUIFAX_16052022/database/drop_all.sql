--
--Drops all adf_metrics database objects
--

--batchjob
@drop_dbms_schedule_job.sql
@drop_dbms_schedule_cleanup_job.sql
@drop_dbms_schedule_hour_aggr_job.sql
@drop_dbms_schedule_day_aggr_job.sql

--sequence
drop sequence adf_metrics_seq;

--view
drop view   adf_metrics_requests_vw;
drop view   adf_metrics_requests_old_vw;
drop view   adf_metrics_plsql_calls_vw;
drop view   adf_metrics_vo_queries_vw;
drop view   adf_metrics_am_transactions_vw;
drop view   adf_metrics_am_pooling_vw;
drop view   adf_metrics_dc_operations_vw;
drop view   adf_metrics_eo_dml_vw;
drop view   adf_metrics_dc_iterator_vw;
drop view   adf_metrics_webs_calls_vw;
drop view   adf_metrics_java_methods_vw;
drop view   adf_metrics_caching_rows_vw;
drop view   adf_metrics_exceptions_vw;
drop view   adf_metrics_requests_err_vw;
drop view   adf_metrics_requests_dtl_vw;

--detail tables
drop table  adf_metrics_am_pooling;
drop table  adf_metrics_am_transactions;
drop table  adf_metrics_dc_operations;
drop table  adf_metrics_eo_dml;
drop table  adf_metrics_plsql_calls;
drop table  adf_metrics_vo_queries;
drop table  adf_metrics_process_exc;
drop table  adf_metrics_dc_iterator;
drop table  adf_metrics_webservice_calls;
drop table  adf_metrics_java_methods;
drop table  adf_metrics_parameters;
drop table  adf_metrics_caching_rows;
drop table  adf_metrics_exec_to_ignore;
drop table  adf_metrics_viewobjects;
drop table  adf_metrics_monitored_users;
drop table  adf_metrics_aggr_job_exc;
drop table  adf_metrics_hour_aggregated;
drop table  adf_metrics_day_aggregated;

--packages
drop package  adf_metrics;
drop package  adf_metrics_job;
drop package  adf_metrics_hour_aggr_job;
drop package  adf_metrics_day_aggr_job;

--dropmain tables
drop table adf_metrics_exceptions;
drop table adf_metrics_request_clobs;
drop table adf_metrics_process_requests;
drop table adf_metrics_requests;
drop table adf_metrics_jmx;



