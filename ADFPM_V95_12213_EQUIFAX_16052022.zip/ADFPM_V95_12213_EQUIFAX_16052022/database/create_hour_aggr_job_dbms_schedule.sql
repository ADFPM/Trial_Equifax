declare
begin
    dbms_scheduler.create_job (
      job_name        => 'adf_metrics_aggr_job_hour',
      job_type        => 'PLSQL_BLOCK',
      job_action      => 'BEGIN adf_metrics_hour_aggr_job.aggregate_hour(); END;',
      start_date      =>  systimestamp,
      repeat_interval => 'freq=hourly;byminute=45',
      end_date        => null,
      enabled         => true,
      comments        => 'Job defined to aggregate hour adf metrics');
end;
/