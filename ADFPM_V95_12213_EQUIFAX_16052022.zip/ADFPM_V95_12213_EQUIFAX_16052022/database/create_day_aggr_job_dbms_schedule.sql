declare
begin
    dbms_scheduler.create_job (
      job_name        => 'adf_metrics_aggr_job_day',
      job_type        => 'PLSQL_BLOCK',
      job_action      => 'BEGIN adf_metrics_day_aggr_job.aggregate_day(); END;',
      start_date      =>  systimestamp,
      repeat_interval => 'freq=hourly;byminute=45',
      end_date        => null,
      enabled         => true,
      comments        => 'Job defined to aggregate day adf metrics');
end;
/